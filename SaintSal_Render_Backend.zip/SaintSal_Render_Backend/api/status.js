const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.send('SaintSal Render API is live.');
});

module.exports = router;