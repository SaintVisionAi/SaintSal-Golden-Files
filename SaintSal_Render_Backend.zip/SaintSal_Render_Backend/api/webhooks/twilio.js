const express = require('express');
const router = express.Router();

router.post('/twilio', (req, res) => {
  console.log('Twilio webhook received:', req.body);
  res.sendStatus(200);
});

module.exports = router;