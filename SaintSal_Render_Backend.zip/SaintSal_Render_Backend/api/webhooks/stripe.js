const express = require('express');
const router = express.Router();

router.post('/stripe', (req, res) => {
  console.log('Stripe webhook received:', req.body);
  res.sendStatus(200);
});

module.exports = router;