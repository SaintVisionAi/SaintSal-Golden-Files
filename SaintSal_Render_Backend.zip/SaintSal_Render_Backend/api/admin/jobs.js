const express = require('express');
const router = express.Router();

router.get('/jobs', (req, res) => {
  res.json({ message: "Background job handler here." });
});

module.exports = router;