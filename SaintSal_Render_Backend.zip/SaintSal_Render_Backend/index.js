const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());
app.use('/api/download', require('./api/download/index'));
app.use('/api/webhooks/stripe', require('./api/webhooks/stripe'));
app.use('/api/webhooks/twilio', require('./api/webhooks/twilio'));
app.use('/api/admin', require('./api/admin/jobs'));
app.use('/api/status', require('./api/status'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`SaintSal backend running on port ${PORT}`));